package com.example.fitorafitnessapp;

import android.content.Intent;
import android.app.PendingIntent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;

import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.common.api.Scope;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;

public class WorkoutPlanActivity extends ComponentActivity {

    // =========================
    // COLORS
    // =========================

    private static final int BACKGROUND = Color.rgb(6, 21, 40);
    private static final int CARD_DARK = Color.rgb(24, 40, 58);
    private static final int WORKOUT_GREEN = Color.rgb(33, 72, 45);
    private static final int NUMBER_GREEN = Color.rgb(155, 229, 43);
    private static final int TODAY_ORANGE = Color.rgb(255, 87, 47);
    private static final int BLUE_BUTTON = Color.rgb(91, 160, 245);
    private static final int REST_TEXT = Color.rgb(64, 82, 103);

    // =========================
    // GOOGLE CALENDAR
    // =========================

    private static final String CALENDAR_SCOPE =
            "https://www.googleapis.com/auth/calendar.readonly";

    private String accessToken;

    private final Set<Integer> workoutDates = new HashSet<>();

    private int currentYear;
    private int currentMonth;

    // =========================
    // VIEWS
    // =========================

    private TextView monthTitle;
    private GridLayout calendarGrid;

    private Button weekButton;
    private Button monthButton;
    private Button todayWorkoutButton;

    // =========================
    // GOOGLE AUTH RESULT
    // =========================

    private final ActivityResultLauncher<IntentSenderRequest>
            authorizationLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartIntentSenderForResult(),
                    result -> {

                        if (result.getResultCode() != RESULT_OK) {
                            Toast.makeText(
                                    this,
                                    "Google authorization cancelled",
                                    Toast.LENGTH_SHORT
                            ).show();
                            return;
                        }

                        try {

                            AuthorizationResult authorizationResult =
                                    Identity
                                            .getAuthorizationClient(this)
                                            .getAuthorizationResultFromIntent(
                                                    result.getData()
                                            );

                            accessToken =
                                    authorizationResult.getAccessToken();

                            if (accessToken != null &&
                                    !accessToken.isEmpty()) {

                                Toast.makeText(
                                        this,
                                        "Google Calendar connected",
                                        Toast.LENGTH_SHORT
                                ).show();

                                loadCalendarEvents();

                            } else {

                                Toast.makeText(
                                        this,
                                        "No Google access token received",
                                        Toast.LENGTH_LONG
                                ).show();
                            }

                        } catch (Exception e) {

                            e.printStackTrace();

                            Toast.makeText(
                                    this,
                                    "Authorization failed",
                                    Toast.LENGTH_LONG
                            ).show();
                        }
                    }
            );

    // =========================
    // ON CREATE
    // =========================

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_workout_plan);

        monthTitle = findViewById(R.id.monthTitle);
        calendarGrid = findViewById(R.id.calendarGrid);

        weekButton = findViewById(R.id.weekButton);
        monthButton = findViewById(R.id.monthButton);
        todayWorkoutButton = findViewById(R.id.todayWorkoutButton);

        Calendar calendar = Calendar.getInstance();

        currentYear = calendar.get(Calendar.YEAR);
        currentMonth = calendar.get(Calendar.MONTH);

        monthButton.setBackgroundColor(BLUE_BUTTON);
        weekButton.setBackgroundColor(Color.rgb(135, 147, 143));

        weekButton.setOnClickListener(v -> {

            Toast.makeText(
                    this,
                    "Week view coming soon",
                    Toast.LENGTH_SHORT
            ).show();

        });

        monthButton.setOnClickListener(v -> {

            showMonthCalendar();

        });

        todayWorkoutButton.setOnClickListener(v -> {

            requestGoogleCalendarAccess();

        });

        View cardCardioRun = findViewById(R.id.cardCardioRun);
        if (cardCardioRun != null) {
            cardCardioRun.setOnClickListener(v -> {
                Intent intent = new Intent(WorkoutPlanActivity.this, MapsActivity.class);
                startActivity(intent);
            });
        }

        showMonthCalendar();
    }

    // =========================
    // GOOGLE AUTHORIZATION
    // =========================

    private void requestGoogleCalendarAccess() {

        Scope calendarScope =
                new Scope(CALENDAR_SCOPE);

        AuthorizationRequest request =
                AuthorizationRequest
                        .builder()
                        .setRequestedScopes(
                                Collections.singletonList(
                                        calendarScope
                                )
                        )
                        .build();

        Identity
                .getAuthorizationClient(this)
                .authorize(request)
                .addOnSuccessListener(result -> {

                    if (result.hasResolution()) {

                        PendingIntent pendingIntent =
                                result.getPendingIntent();

                        if (pendingIntent != null) {

                            IntentSenderRequest senderRequest =
                                    new IntentSenderRequest.Builder(
                                            pendingIntent.getIntentSender()
                                    ).build();

                            authorizationLauncher.launch(
                                    senderRequest
                            );

                        } else {

                            Toast.makeText(
                                    this,
                                    "Google authorization is unavailable",
                                    Toast.LENGTH_LONG
                            ).show();
                        }

                    } else {

                        accessToken =
                                result.getAccessToken();

                        if (accessToken != null &&
                                !accessToken.isEmpty()) {

                            loadCalendarEvents();

                        } else {

                            Toast.makeText(
                                    this,
                                    "Google Calendar access was not granted",
                                    Toast.LENGTH_LONG
                            ).show();
                        }
                    }

                })
                .addOnFailureListener(e -> {

                    e.printStackTrace();

                    Toast.makeText(
                            this,
                            "Google authorization failed",
                            Toast.LENGTH_LONG
                    ).show();
                });
    }

    // =========================
    // LOAD GOOGLE CALENDAR
    // =========================

    private void loadCalendarEvents() {

        if (accessToken == null ||
                accessToken.isEmpty()) {
            return;
        }

        new Thread(() -> {

            HttpURLConnection connection = null;

            try {

                Calendar start = Calendar.getInstance(
                        TimeZone.getTimeZone("UTC")
                );

                start.clear();

                start.set(
                        currentYear,
                        currentMonth,
                        1,
                        0,
                        0,
                        0
                );

                Calendar end = Calendar.getInstance(
                        TimeZone.getTimeZone("UTC")
                );

                end.clear();

                end.set(
                        currentYear,
                        currentMonth,
                        1,
                        0,
                        0,
                        0
                );

                end.add(Calendar.MONTH, 1);

                String timeMin =
                        formatGoogleDate(start);

                String timeMax =
                        formatGoogleDate(end);

                String urlString =
                        "https://www.googleapis.com/calendar/v3/" +
                                "calendars/primary/events" +
                                "?timeMin=" + timeMin +
                                "&timeMax=" + timeMax +
                                "&singleEvents=true" +
                                "&orderBy=startTime";

                URL url = new URL(urlString);

                connection =
                        (HttpURLConnection) url.openConnection();

                connection.setRequestMethod("GET");

                connection.setRequestProperty(
                        "Authorization",
                        "Bearer " + accessToken
                );

                connection.setRequestProperty(
                        "Accept",
                        "application/json"
                );

                connection.setConnectTimeout(15000);
                connection.setReadTimeout(15000);

                int responseCode =
                        connection.getResponseCode();

                if (responseCode == HttpURLConnection.HTTP_OK) {

                    BufferedReader reader =
                            new BufferedReader(
                                    new InputStreamReader(
                                            connection.getInputStream()
                                    )
                            );

                    StringBuilder response =
                            new StringBuilder();

                    String line;

                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    reader.close();

                    parseCalendarEvents(
                            response.toString()
                    );

                } else {

                    runOnUiThread(() ->
                            Toast.makeText(
                                    this,
                                    "Calendar API error: "
                                            + responseCode,
                                    Toast.LENGTH_LONG
                            ).show()
                    );
                }

            } catch (Exception e) {

                e.printStackTrace();

                runOnUiThread(() ->
                        Toast.makeText(
                                this,
                                "Could not load Google Calendar",
                                Toast.LENGTH_LONG
                        ).show()
                );

            } finally {

                if (connection != null) {
                    connection.disconnect();
                }
            }

        }).start();
    }

    // =========================
    // PARSE EVENTS
    // =========================

    private void parseCalendarEvents(String json) {

        try {

            JSONObject root =
                    new JSONObject(json);

            JSONArray items =
                    root.optJSONArray("items");

            workoutDates.clear();

            if (items != null) {

                for (int i = 0;
                     i < items.length();
                     i++) {

                    JSONObject event =
                            items.getJSONObject(i);

                    JSONObject start =
                            event.optJSONObject("start");

                    if (start == null) {
                        continue;
                    }

                    String date =
                            start.optString(
                                    "date",
                                    ""
                            );

                    if (!date.isEmpty()) {

                        addWorkoutDate(date);

                    } else {

                        String dateTime =
                                start.optString(
                                        "dateTime",
                                        ""
                                );

                        if (!dateTime.isEmpty() &&
                                dateTime.length() >= 10) {

                            String datePart =
                                    dateTime.substring(0, 10);

                            addWorkoutDate(datePart);
                        }
                    }
                }
            }

            runOnUiThread(() -> {

                showMonthCalendar();

                Toast.makeText(
                        this,
                        workoutDates.size()
                                + " workout dates loaded",
                        Toast.LENGTH_SHORT
                ).show();
            });

        } catch (Exception e) {

            e.printStackTrace();

            runOnUiThread(() ->
                    Toast.makeText(
                            this,
                            "Error reading calendar data",
                            Toast.LENGTH_LONG
                    ).show()
            );
        }
    }

    // =========================
    // ADD WORKOUT DATE
    // =========================

    private void addWorkoutDate(String date) {

        try {

            if (date == null ||
                    date.length() < 10) {
                return;
            }

            int year =
                    Integer.parseInt(
                            date.substring(0, 4)
                    );

            int month =
                    Integer.parseInt(
                            date.substring(5, 7)
                    ) - 1;

            int day =
                    Integer.parseInt(
                            date.substring(8, 10)
                    );

            if (year == currentYear &&
                    month == currentMonth) {

                workoutDates.add(day);
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    // =========================
    // GOOGLE DATE FORMAT
    // =========================

    private String formatGoogleDate(Calendar calendar) {

        SimpleDateFormat formatter =
                new SimpleDateFormat(
                        "yyyy-MM-dd'T'HH:mm:ss'Z'",
                        Locale.US
                );

        formatter.setTimeZone(
                TimeZone.getTimeZone("UTC")
        );

        return formatter.format(
                calendar.getTime()
        );
    }

    // =========================
    // SHOW MONTH CALENDAR
    // =========================

    private void showMonthCalendar() {

        calendarGrid.removeAllViews();

        Calendar firstDay = Calendar.getInstance();

        firstDay.set(
                currentYear,
                currentMonth,
                1
        );

        int daysInMonth =
                firstDay.getActualMaximum(
                        Calendar.DAY_OF_MONTH
                );

        int firstDayOffset =
                firstDay.get(Calendar.DAY_OF_WEEK) - 1;

        SimpleDateFormat monthFormatter =
                new SimpleDateFormat(
                        "MMMM yyyy",
                        Locale.US
                );

        monthTitle.setText(
                monthFormatter.format(
                        firstDay.getTime()
                )
        );

        String[] weekDays = {
                "S", "M", "T", "W",
                "T", "F", "S"
        };

        // Weekday headers
        for (String day : weekDays) {

            TextView label =
                    new TextView(this);

            label.setText(day);
            label.setTextColor(
                    Color.rgb(82, 97, 116)
            );
            label.setTextSize(10);
            label.setGravity(Gravity.CENTER);

            GridLayout.LayoutParams params =
                    new GridLayout.LayoutParams();

            params.width = 0;
            params.height = dp(30);

            params.columnSpec =
                    GridLayout.spec(
                            GridLayout.UNDEFINED,
                            1f
                    );

            label.setLayoutParams(params);

            calendarGrid.addView(label);
        }

        // Empty cells
        for (int i = 0;
             i < firstDayOffset;
             i++) {

            TextView empty =
                    new TextView(this);

            GridLayout.LayoutParams params =
                    new GridLayout.LayoutParams();

            params.width = 0;
            params.height = dp(46);

            params.columnSpec =
                    GridLayout.spec(
                            GridLayout.UNDEFINED,
                            1f
                    );

            empty.setLayoutParams(params);

            calendarGrid.addView(empty);
        }

        Calendar today =
                Calendar.getInstance();

        // Days
        for (int day = 1;
             day <= daysInMonth;
             day++) {

            boolean isWorkout =
                    workoutDates.contains(day);

            boolean isToday =
                    today.get(Calendar.YEAR)
                            == currentYear
                            &&
                            today.get(Calendar.MONTH)
                                    == currentMonth
                            &&
                            today.get(Calendar.DAY_OF_MONTH)
                                    == day;

            TextView dayView =
                    createCalendarDay(
                            day,
                            isWorkout,
                            isToday
                    );

            calendarGrid.addView(dayView);
        }
    }

    // =========================
    // CREATE CALENDAR DAY
    // =========================

    private TextView createCalendarDay(
            int day,
            boolean workout,
            boolean today
    ) {

        TextView textView =
                new TextView(this);

        textView.setText(
                String.valueOf(day)
        );

        textView.setTextSize(12);

        textView.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD
        );

        textView.setGravity(Gravity.CENTER);

        int backgroundColor;
        int textColor;

        if (today) {

            backgroundColor = TODAY_ORANGE;
            textColor = Color.WHITE;

        } else if (workout) {

            backgroundColor = WORKOUT_GREEN;
            textColor = NUMBER_GREEN;

        } else {

            backgroundColor = CARD_DARK;
            textColor = REST_TEXT;
        }

        textView.setTextColor(textColor);

        android.graphics.drawable.GradientDrawable background =
                new android.graphics.drawable.GradientDrawable();

        background.setColor(backgroundColor);
        background.setCornerRadius(dp(10));

        textView.setBackground(background);

        GridLayout.LayoutParams params =
                new GridLayout.LayoutParams();

        params.width = 0;
        params.height = dp(46);

        params.columnSpec =
                GridLayout.spec(
                        GridLayout.UNDEFINED,
                        1f
                );

        params.setMargins(
                dp(2),
                dp(2),
                dp(2),
                dp(2)
        );

        textView.setLayoutParams(params);

        return textView;
    }

    // =========================
    // DP
    // =========================

    private int dp(int value) {

        return (int) (
                value *
                        getResources()
                                .getDisplayMetrics()
                                .density
        );
    }
}