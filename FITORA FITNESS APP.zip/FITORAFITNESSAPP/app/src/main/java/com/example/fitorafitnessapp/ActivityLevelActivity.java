package com.example.fitorafitnessapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityLevelActivity extends AppCompatActivity {

    private View optionSedentary;
    private View optionLightly;
    private View optionModerate;
    private View optionVeryActive;
    private View optionExtraActive;

    private View radioSedentary;
    private View radioLightly;
    private View radioModerate;
    private View radioVeryActive;
    private View radioExtraActive;

    private Button btnContinue;
    private View btnBack;

    private String selectedActivity = "Moderate";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_level);

        btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // Find activity options
        optionSedentary = findViewById(R.id.optionSedentary);
        optionLightly = findViewById(R.id.optionLightly);
        optionModerate = findViewById(R.id.optionModerate);
        optionVeryActive = findViewById(R.id.optionVeryActive);
        optionExtraActive = findViewById(R.id.optionExtraActive);

        // Find radio indicators
        radioSedentary = findViewById(R.id.radioSedentary);
        radioLightly = findViewById(R.id.radioLightly);
        radioModerate = findViewById(R.id.radioModerate);
        radioVeryActive = findViewById(R.id.radioVeryActive);
        radioExtraActive = findViewById(R.id.radioExtraActive);

        // Find Continue button
        btnContinue = findViewById(R.id.btnContinue);

        // Select Moderate by default
        selectRadio(radioModerate);

        // Sedentary
        if (optionSedentary != null) {
            optionSedentary.setOnClickListener(v -> {
                selectedActivity = "Sedentary";
                selectRadio(radioSedentary);
            });
        }

        // Lightly Active
        if (optionLightly != null) {
            optionLightly.setOnClickListener(v -> {
                selectedActivity = "Lightly Active";
                selectRadio(radioLightly);
            });
        }

        // Moderate
        if (optionModerate != null) {
            optionModerate.setOnClickListener(v -> {
                selectedActivity = "Moderate";
                selectRadio(radioModerate);
            });
        }

        // Very Active
        if (optionVeryActive != null) {
            optionVeryActive.setOnClickListener(v -> {
                selectedActivity = "Very Active";
                selectRadio(radioVeryActive);
            });
        }

        // Extra Active
        if (optionExtraActive != null) {
            optionExtraActive.setOnClickListener(v -> {
                selectedActivity = "Extra Active";
                selectRadio(radioExtraActive);
            });
        }

        // Continue button
        if (btnContinue != null) {
            btnContinue.setOnClickListener(v -> {

                // Save activity level
                getSharedPreferences(
                        "FITORA_ACCOUNTS",
                        MODE_PRIVATE
                )
                        .edit()
                        .putString("activity_level", selectedActivity)
                        .apply();

                Toast.makeText(
                        ActivityLevelActivity.this,
                        "Activity level saved",
                        Toast.LENGTH_SHORT
                ).show();

                // Open Fitness Goal screen
                Intent intent = new Intent(
                        ActivityLevelActivity.this,
                        FitnessGoalActivity.class
                );

                // Send selected activity level
                intent.putExtra(
                        "activity_level",
                        selectedActivity
                );

                startActivity(intent);
            });
        }
    }

    private void selectRadio(View selectedRadio) {
        if (radioSedentary != null) radioSedentary.setBackgroundResource(R.drawable.bg_radio_unselected);
        if (radioLightly != null) radioLightly.setBackgroundResource(R.drawable.bg_radio_unselected);
        if (radioModerate != null) radioModerate.setBackgroundResource(R.drawable.bg_radio_unselected);
        if (radioVeryActive != null) radioVeryActive.setBackgroundResource(R.drawable.bg_radio_unselected);
        if (radioExtraActive != null) radioExtraActive.setBackgroundResource(R.drawable.bg_radio_unselected);

        if (selectedRadio != null) {
            selectedRadio.setBackgroundResource(R.drawable.bg_radio_selected);
        }
    }
}
