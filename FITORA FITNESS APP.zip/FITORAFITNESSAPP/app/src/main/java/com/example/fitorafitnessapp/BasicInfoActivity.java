package com.example.fitorafitnessapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class BasicInfoActivity extends AppCompatActivity {

    Button btnMale, btnFemale, btnContinue;
    EditText etAge, etHeight, etWeight;

    String selectedSex = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basic_info);

        // Find views
        btnMale = findViewById(R.id.btnMale);
        btnFemale = findViewById(R.id.btnFemale);
        btnContinue = findViewById(R.id.btnContinue);

        etAge = findViewById(R.id.etAge);
        etHeight = findViewById(R.id.etHeight);
        etWeight = findViewById(R.id.etWeight);

        // MALE
        btnMale.setOnClickListener(v -> {
            selectedSex = "Male";
            btnMale.setBackgroundTintList(ColorStateList.valueOf(0xFF63AFFF));
            btnMale.setTextColor(Color.WHITE);

            btnFemale.setBackgroundTintList(ColorStateList.valueOf(0xFFF4FAF7));
            btnFemale.setTextColor(0xFF222222);
        });

        // FEMALE
        btnFemale.setOnClickListener(v -> {
            selectedSex = "Female";
            btnFemale.setBackgroundTintList(ColorStateList.valueOf(0xFF63AFFF));
            btnFemale.setTextColor(Color.WHITE);

            btnMale.setBackgroundTintList(ColorStateList.valueOf(0xFFF4FAF7));
            btnMale.setTextColor(0xFF222222);
        });

        // CONTINUE
        btnContinue.setOnClickListener(v -> {

            String age = etAge.getText().toString().trim();
            String height = etHeight.getText().toString().trim();
            String weight = etWeight.getText().toString().trim();

            // Check sex
            if (selectedSex.isEmpty()) {
                Toast.makeText(
                        BasicInfoActivity.this,
                        "Please select your sex",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            // Check age
            if (age.isEmpty()) {
                etAge.setError("Enter your age");
                etAge.requestFocus();
                return;
            }

            // Check height
            if (height.isEmpty()) {
                etHeight.setError("Enter your height");
                etHeight.requestFocus();
                return;
            }

            // Check weight
            if (weight.isEmpty()) {
                etWeight.setError("Enter your weight");
                etWeight.requestFocus();
                return;
            }

            // SAVE BASIC INFORMATION
            SharedPreferences account =
                    getSharedPreferences("FITORA_ACCOUNTS", MODE_PRIVATE);

            account.edit()
                    .putString("sex", selectedSex)
                    .putString("age", age)
                    .putString("height", height)
                    .putString("weight", weight)
                    .apply();

            // Success
            Toast.makeText(
                    BasicInfoActivity.this,
                    "Basic information saved",
                    Toast.LENGTH_SHORT
            ).show();

            // Open Activity Level
            Intent intent = new Intent(
                    BasicInfoActivity.this,
                    ActivityLevelActivity.class
            );

            intent.putExtra("sex", selectedSex);
            intent.putExtra("age", age);
            intent.putExtra("height", height);
            intent.putExtra("weight", weight);

            startActivity(intent);
        });
    }
}
