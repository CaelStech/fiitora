package com.example.fitorafitnessapp;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    private ImageView logo;
    private TextView tagline;

    private final Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        logo = findViewById(R.id.splashLogo);
        tagline = findViewById(R.id.splashTagline);

        // =========================================
        // TAGLINE TEXT COLORS
        // =========================================

        SpannableString taglineText =
                new SpannableString("Your Fitness. Your Journey.");

        int green = Color.rgb(115, 255, 40);

        // Fitness.
        taglineText.setSpan(
                new ForegroundColorSpan(green),
                5,
                13,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        );

        // Journey.
        taglineText.setSpan(
                new ForegroundColorSpan(green),
                19,
                27,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        );

        tagline.setText(taglineText);

        // =========================================
        // INITIAL STATE
        // =========================================

        // Logo starts extremely large
        logo.setScaleX(10.10f);
        logo.setScaleY(10.10f);

        // Logo is initially invisible
        logo.setAlpha(0f);

        // Tagline is invisible
        tagline.setAlpha(0f);

        // =========================================
        // LOGO FADE IN
        // =========================================

        ObjectAnimator logoAppear =
                ObjectAnimator.ofFloat(
                        logo,
                        View.ALPHA,
                        0f,
                        1f
                );

        logoAppear.setDuration(100);

        // =========================================
        // LOGO ZOOMS OUT
        // =========================================

        ObjectAnimator scaleX =
                ObjectAnimator.ofFloat(
                        logo,
                        View.SCALE_X,
                        10.10f,
                        1f
                );

        ObjectAnimator scaleY =
                ObjectAnimator.ofFloat(
                        logo,
                        View.SCALE_Y,
                        10.10f,
                        1f
                );

        scaleX.setDuration(900);
        scaleY.setDuration(900);

        scaleX.setInterpolator(
                new DecelerateInterpolator(1.5f)
        );

        scaleY.setInterpolator(
                new DecelerateInterpolator(1.5f)
        );

        // =========================================
        // RUN LOGO ANIMATION
        // =========================================

        AnimatorSet logoAnimation = new AnimatorSet();

        logoAnimation.playTogether(
                logoAppear,
                scaleX,
                scaleY
        );

        logoAnimation.setStartDelay(180);
        logoAnimation.start();

        // =========================================
        // TAGLINE APPEARS
        // =========================================

        handler.postDelayed(() -> {

            ObjectAnimator taglineFade =
                    ObjectAnimator.ofFloat(
                            tagline,
                            View.ALPHA,
                            0f,
                            1f
                    );

            taglineFade.setDuration(500);

            taglineFade.setInterpolator(
                    new DecelerateInterpolator()
            );

            taglineFade.start();

        }, 1700);

        // =========================================
        // OPEN LOGIN SCREEN
        // =========================================

        handler.postDelayed(() -> {

            Intent intent = new Intent(
                    SplashActivity.this,
                    LoginActivity.class
            );

            startActivity(intent);

            overridePendingTransition(
                    android.R.anim.fade_in,
                    android.R.anim.fade_out
            );

            finish();

        }, 3200);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        handler.removeCallbacksAndMessages(null);
    }
}