// SignupActivity.java

package com.example.fitorafitnessapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SignupActivity extends AppCompatActivity {

    EditText etName, etEmail, etPassword, etConfirmPassword;
    Button btnCreateAccount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);

        btnCreateAccount = findViewById(R.id.btnCreateAccount);

        btnCreateAccount.setOnClickListener(v -> {

            String name = etName.getText().toString().trim();
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString();
            String confirmPassword =
                    etConfirmPassword.getText().toString();

            if (name.isEmpty() ||
                    email.isEmpty() ||
                    password.isEmpty() ||
                    confirmPassword.isEmpty()) {

                Toast.makeText(
                        SignupActivity.this,
                        "Please fill in all fields",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            if (!password.equals(confirmPassword)) {

                Toast.makeText(
                        SignupActivity.this,
                        "Passwords do not match",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            // TEMPORARY LOCAL ACCOUNT STORAGE
            getSharedPreferences("FITORA_ACCOUNTS", MODE_PRIVATE)
                    .edit()
                    .putString("name", name)
                    .putString("email", email)
                    .putString("password", password)
                    .putBoolean("account_created", true)
                    .apply();

            Toast.makeText(
                    SignupActivity.this,
                    "Account created successfully!",
                    Toast.LENGTH_SHORT
            ).show();

            Intent intent = new Intent(
                    SignupActivity.this,
                    BasicInfoActivity.class
            );

            startActivity(intent);
            finish();
        });
    }
}