package com.example.fitorafitnessapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class FitnessGoalActivity extends AppCompatActivity {

    View goalLoseWeight;
    View goalBuildMuscle;
    View goalMaintain;

    TextView checkLoseWeight;
    TextView checkBuildMuscle;
    TextView checkMaintain;

    Button btnCalculateBMI;
    View btnBack;

    String selectedGoal = "Lose Weight";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fitness_goal);

        btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        goalLoseWeight = findViewById(R.id.goalLoseWeight);
        goalBuildMuscle = findViewById(R.id.goalBuildMuscle);
        goalMaintain = findViewById(R.id.goalMaintain);

        checkLoseWeight = findViewById(R.id.checkLoseWeight);
        checkBuildMuscle = findViewById(R.id.checkBuildMuscle);
        checkMaintain = findViewById(R.id.checkMaintain);

        btnCalculateBMI = findViewById(R.id.btnCalculateBMI);

        // LOSE WEIGHT
        if (goalLoseWeight != null) {
            goalLoseWeight.setOnClickListener(v -> {
                selectedGoal = "Lose Weight";
                selectGoal(checkLoseWeight);
            });
        }

        // BUILD MUSCLE
        if (goalBuildMuscle != null) {
            goalBuildMuscle.setOnClickListener(v -> {
                selectedGoal = "Build Muscle";
                selectGoal(checkBuildMuscle);
            });
        }

        // MAINTAIN
        if (goalMaintain != null) {
            goalMaintain.setOnClickListener(v -> {
                selectedGoal = "Maintain";
                selectGoal(checkMaintain);
            });
        }

        // CALCULATE BMI
        if (btnCalculateBMI != null) {
            btnCalculateBMI.setOnClickListener(v -> {

                getSharedPreferences(
                        "FITORA_ACCOUNTS",
                        MODE_PRIVATE
                ).edit()
                        .putString("fitness_goal", selectedGoal)
                        .apply();

                Toast.makeText(
                        this,
                        "Fitness goal saved",
                        Toast.LENGTH_SHORT
                ).show();

                Intent intent = new Intent(
                        FitnessGoalActivity.this,
                        BMICalculationActivity.class
                );

                intent.putExtra(
                        "fitness_goal",
                        selectedGoal
                );

                startActivity(intent);
            });
        }
    }

    private void selectGoal(TextView selectedCheck) {
        if (checkLoseWeight != null) checkLoseWeight.setBackgroundResource(R.drawable.bg_goal_unselected);
        if (checkBuildMuscle != null) checkBuildMuscle.setBackgroundResource(R.drawable.bg_goal_unselected);
        if (checkMaintain != null) checkMaintain.setBackgroundResource(R.drawable.bg_goal_unselected);

        if (selectedCheck != null) {
            selectedCheck.setBackgroundResource(R.drawable.bg_goal_selected);
        }
    }
}
