package com.example.fitorafitnessapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;
import androidx.health.connect.client.HealthConnectClient;
import androidx.health.connect.client.PermissionController;
import androidx.health.connect.client.aggregate.AggregateMetric;
import androidx.health.connect.client.aggregate.AggregationResult;
import androidx.health.connect.client.permission.HealthPermission;
import androidx.health.connect.client.records.StepsRecord;
import androidx.health.connect.client.records.TotalCaloriesBurnedRecord;
import androidx.health.connect.client.request.AggregateRequest;
import androidx.health.connect.client.time.TimeRangeFilter;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import kotlin.jvm.JvmClassMappingKt;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.Dispatchers;

public class HomeActivity extends AppCompatActivity {

    private static final String TAG = "HomeActivity";

    private TextView tvStepsToday;
    private TextView tvKcalBurned;

    private HealthConnectClient healthConnectClient;

    private final Set<String> permissions = new HashSet<>();
    private ActivityResultLauncher<Set<String>> requestPermissionLauncher;
    private final ExecutorService executorService = Executors.newSingleThreadExecutor();

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        TextView tvName = findViewById(R.id.tvName);
        tvStepsToday = findViewById(R.id.tvStepsToday);
        tvKcalBurned = findViewById(R.id.tvKcalBurned);

        permissions.add(HealthPermission.getReadPermission(JvmClassMappingKt.getKotlinClass(StepsRecord.class)));
        permissions.add(HealthPermission.getReadPermission(JvmClassMappingKt.getKotlinClass(TotalCaloriesBurnedRecord.class)));

        // Setup permission launcher using PermissionController contract
        requestPermissionLauncher = registerForActivityResult(
                PermissionController.createRequestPermissionResultContract(),
                granted -> {
                    if (granted != null && granted.containsAll(permissions)) {
                        fetchHealthData();
                    } else {
                        Toast.makeText(this, "Health Connect permissions required to show live steps & calories.", Toast.LENGTH_LONG).show();
                    }
                }
        );

        // Check Health Connect availability
        int sdkStatus = HealthConnectClient.getSdkStatus(this);
        if (sdkStatus == HealthConnectClient.SDK_AVAILABLE) {
            healthConnectClient = HealthConnectClient.getOrCreate(this);
            checkAndFetchData();
        } else {
            if (tvStepsToday != null) tvStepsToday.setText("0");
            if (tvKcalBurned != null) tvKcalBurned.setText("0");
        }

        // Get saved user name
        String savedName = getSharedPreferences(
                "FITORA_ACCOUNTS",
                MODE_PRIVATE
        ).getString("first_name", "Juan");

        String userName = savedName.trim().isEmpty() ? "Juan" : savedName;

        if (tvName != null) {
            tvName.setText(userName + " 👋");
        }

        // Start workout button -> Opens Google Map for Cardio Run
        View btnStartWorkout = findViewById(R.id.btnStartWorkout);
        if (btnStartWorkout != null) {
            btnStartWorkout.setOnClickListener(v -> {
                Intent intent = new Intent(HomeActivity.this, MapsActivity.class);
                startActivity(intent);
            });
        }

        setupQuickActionsAndNav();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executorService.shutdown();
    }

    private void checkAndFetchData() {
        if (healthConnectClient == null) return;

        executorService.execute(() -> {
            try {
                Set<String> granted = BuildersKt.runBlocking(
                        Dispatchers.getIO(),
                        (coroutineScope, continuation) -> healthConnectClient.getPermissionController().getGrantedPermissions(continuation)
                );

                if (granted != null && granted.containsAll(permissions)) {
                    fetchHealthData();
                } else {
                    runOnUiThread(() -> requestPermissionLauncher.launch(permissions));
                }
            } catch (Exception e) {
                Log.e(TAG, "Error checking permissions", e);
                if (e instanceof InterruptedException) {
                    Thread.currentThread().interrupt();
                }
            }
        });
    }

    private void fetchHealthData() {
        if (healthConnectClient == null) return;

        executorService.execute(() -> {
            try {
                Instant startOfDay = LocalDate.now(ZoneId.systemDefault()).atStartOfDay(ZoneId.systemDefault()).toInstant();
                Instant now = Instant.now();
                TimeRangeFilter timeRange = TimeRangeFilter.between(startOfDay, now);

                Set<AggregateMetric<?>> metrics = new HashSet<>();
                metrics.add(StepsRecord.COUNT_TOTAL);
                metrics.add(TotalCaloriesBurnedRecord.ENERGY_TOTAL);

                AggregateRequest request = new AggregateRequest(metrics, timeRange, Collections.emptySet());

                AggregationResult response = BuildersKt.runBlocking(
                        Dispatchers.getIO(),
                        (coroutineScope, continuation) -> healthConnectClient.aggregate(request, continuation)
                );

                Long totalSteps = response.get(StepsRecord.COUNT_TOTAL);
                androidx.health.connect.client.units.Energy totalCalories = response.get(TotalCaloriesBurnedRecord.ENERGY_TOTAL);

                long steps = Objects.requireNonNullElse(totalSteps, 0L);
                long calories = totalCalories != null ? Math.round(totalCalories.getKilocalories()) : 0L;

                runOnUiThread(() -> {
                    if (tvStepsToday != null) {
                        tvStepsToday.setText(String.format(Locale.US, "%,d", steps));
                    }
                    if (tvKcalBurned != null) {
                        tvKcalBurned.setText(String.format(Locale.US, "%,d", calories));
                    }
                });

            } catch (Exception e) {
                Log.e(TAG, "Error fetching health data", e);
                if (e instanceof InterruptedException) {
                    Thread.currentThread().interrupt();
                }
            }
        });
    }

    private void setupQuickActionsAndNav() {
        View actionMeal = findViewById(R.id.actionMeal);
        if (actionMeal != null) {
            actionMeal.setOnClickListener(v -> Toast.makeText(HomeActivity.this, "Meal Plan", Toast.LENGTH_SHORT).show());
        }

        View actionWorkout = findViewById(R.id.actionWorkout);
        if (actionWorkout != null) {
            actionWorkout.setOnClickListener(v -> {
                Intent intent = new Intent(HomeActivity.this, MapsActivity.class);
                startActivity(intent);
            });
        }

        View actionCalories = findViewById(R.id.actionCalories);
        if (actionCalories != null) {
            actionCalories.setOnClickListener(v -> Toast.makeText(HomeActivity.this, "Calories", Toast.LENGTH_SHORT).show());
        }

        View actionPhotos = findViewById(R.id.actionPhotos);
        if (actionPhotos != null) {
            actionPhotos.setOnClickListener(v -> Toast.makeText(HomeActivity.this, "Photos", Toast.LENGTH_SHORT).show());
        }

        View navHome = findViewById(R.id.navHome);
        if (navHome != null) {
            navHome.setOnClickListener(v -> Toast.makeText(HomeActivity.this, "Home", Toast.LENGTH_SHORT).show());
        }

        View navWorkout = findViewById(R.id.navWorkout);
        if (navWorkout != null) {
            navWorkout.setOnClickListener(v -> {
                Intent intent = new Intent(HomeActivity.this, MapsActivity.class);
                startActivity(intent);
            });
        }

        View navMeals = findViewById(R.id.navMeals);
        if (navMeals != null) {
            navMeals.setOnClickListener(v -> Toast.makeText(HomeActivity.this, "Meals", Toast.LENGTH_SHORT).show());
        }

        View navProgress = findViewById(R.id.navProgress);
        if (navProgress != null) {
            navProgress.setOnClickListener(v -> Toast.makeText(HomeActivity.this, "Progress", Toast.LENGTH_SHORT).show());
        }

        View navProfile = findViewById(R.id.navProfile);
        if (navProfile != null) {
            navProfile.setOnClickListener(v -> Toast.makeText(HomeActivity.this, "Profile", Toast.LENGTH_SHORT).show());
        }
    }
}
