package com.example.fitorafitnessapp;

import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    EditText email, password;
    Button loginButton, googleButton, facebookButton;
    TextView forgotPassword, signUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);
        googleButton = findViewById(R.id.googleButton);
        facebookButton = findViewById(R.id.facebookButton);
        forgotPassword = findViewById(R.id.forgotPassword);
        signUp = findViewById(R.id.signUp);

        // =========================================
        // SIGN UP TEXT COLOR
        // =========================================
        SpannableString signUpText = new SpannableString("No account yet? Sign up free");
        signUpText.setSpan(
                new ForegroundColorSpan(Color.parseColor("#63AFFF")),
                15,
                28,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        );
        signUp.setText(signUpText);

        // =========================================
        // LOGIN
        // =========================================
        loginButton.setOnClickListener(v -> {

            String emailText = email.getText().toString().trim();
            String passwordText = password.getText().toString().trim();

            if (emailText.isEmpty()) {
                email.setError("Enter your email");
                email.requestFocus();
                return;
            }

            if (passwordText.isEmpty()) {
                password.setError("Enter your password");
                password.requestFocus();
                return;
            }

            Toast.makeText(
                    LoginActivity.this,
                    "Login successful",
                    Toast.LENGTH_SHORT
            ).show();

            Intent intent = new Intent(
                    LoginActivity.this,
                    BasicInfoActivity.class
            );

            startActivity(intent);
        });

        // =========================================
        // GOOGLE
        // =========================================
        googleButton.setOnClickListener(v -> {
            Toast.makeText(
                    LoginActivity.this,
                    "Continue with Google",
                    Toast.LENGTH_SHORT
            ).show();
        });

        // =========================================
        // FACEBOOK
        // =========================================
        facebookButton.setOnClickListener(v -> {
            Toast.makeText(
                    LoginActivity.this,
                    "Continue with Facebook",
                    Toast.LENGTH_SHORT
            ).show();
        });

        // =========================================
        // FORGOT PASSWORD
        // =========================================
        forgotPassword.setOnClickListener(v -> {
            Toast.makeText(
                    LoginActivity.this,
                    "Forgot password",
                    Toast.LENGTH_SHORT
            ).show();
        });

        // =========================================
        // SIGN UP
        // =========================================
        signUp.setOnClickListener(v -> {

            Intent intent = new Intent(
                    LoginActivity.this,
                    SignupActivity.class
            );

            startActivity(intent);

        });
    }
}