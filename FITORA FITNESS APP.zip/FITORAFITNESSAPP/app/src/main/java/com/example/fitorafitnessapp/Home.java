package com.example.fitorafitnessapp;

// Code moved to HomeActivity.java
