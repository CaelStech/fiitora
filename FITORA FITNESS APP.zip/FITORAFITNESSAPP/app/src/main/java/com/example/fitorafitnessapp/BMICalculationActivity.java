package com.example.fitorafitnessapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class BMICalculationActivity extends AppCompatActivity {

    TextView tvBMI;
    TextView tvBMIStatus;
    TextView tvHeight;
    TextView tvWeight;
    TextView tvAge;
    TextView tvMessage;

    Button btnWorkoutPlan;
    View btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi_result);

        btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        tvBMI = findViewById(R.id.tvBMI);
        tvBMIStatus = findViewById(R.id.tvBMIStatus);
        tvHeight = findViewById(R.id.tvHeight);
        tvWeight = findViewById(R.id.tvWeight);
        tvAge = findViewById(R.id.tvAge);
        tvMessage = findViewById(R.id.tvMessage);

        btnWorkoutPlan = findViewById(R.id.btnWorkoutPlan);

        // Get saved information
        String heightText = getSharedPreferences(
                "FITORA_ACCOUNTS",
                MODE_PRIVATE
        ).getString("height", "170");

        String weightText = getSharedPreferences(
                "FITORA_ACCOUNTS",
                MODE_PRIVATE
        ).getString("weight", "67");

        String ageText = getSharedPreferences(
                "FITORA_ACCOUNTS",
                MODE_PRIVATE
        ).getString("age", "25");

        try {
            double height = Double.parseDouble(heightText);
            double weight = Double.parseDouble(weightText);

            double heightMeters = height / 100;
            double bmi = weight / (heightMeters * heightMeters);

            String formattedBMI = String.format("%.1f", bmi);
            tvBMI.setText(formattedBMI);

            String status;
            if (bmi < 18.5) {
                status = "Underweight";
            } else if (bmi < 25) {
                status = "Normal";
            } else if (bmi < 30) {
                status = "Overweight";
            } else {
                status = "Obese";
            }

            tvBMIStatus.setText(status);

            if (tvMessage != null) {
                tvMessage.setText("Your BMI is " + formattedBMI + " (" + status + "). Maintain your healthy lifestyle by staying active and eating balanced meals.");
            }

        } catch (Exception e) {
            tvBMI.setText("23.1");
            tvBMIStatus.setText("Normal");
        }

        tvHeight.setText(heightText + " cm");
        tvWeight.setText(weightText + " kg");
        tvAge.setText(ageText + " yrs");

        if (btnWorkoutPlan != null) {
            btnWorkoutPlan.setOnClickListener(v -> {
                Intent intent = new Intent(
                        BMICalculationActivity.this,
                        ExercisePreferencesActivity.class
                );
                startActivity(intent);
            });
        }
    }
}
