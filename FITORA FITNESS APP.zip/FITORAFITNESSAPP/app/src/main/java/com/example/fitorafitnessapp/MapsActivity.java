package com.example.fitorafitnessapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationClient;
    private LocationCallback locationCallback;
    private LocationRequest locationRequest;

    private TextView tvTime, tvDistance, tvPace;
    private Button btnStart, btnPauseResume, btnFinish;
    private ImageView btnBack;

    private boolean isTracking = false;
    private boolean isPaused = false;

    private long secondsElapsed = 0;
    private Handler timerHandler = new Handler(Looper.getMainLooper());
    private Runnable timerRunnable;

    private double totalDistanceMeters = 0.0;
    private Location lastLocation = null;
    private List<LatLng> routePoints = new ArrayList<>();
    private Polyline routePolyline;

    private final ActivityResultLauncher<String[]> locationPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                Boolean fineGranted = result.getOrDefault(Manifest.permission.ACCESS_FINE_LOCATION, false);
                Boolean coarseGranted = result.getOrDefault(Manifest.permission.ACCESS_COARSE_LOCATION, false);

                if ((fineGranted != null && fineGranted) || (coarseGranted != null && coarseGranted)) {
                    enableUserLocationAndStart();
                } else {
                    Toast.makeText(this, "Location permission is required for Cardio Run tracking.", Toast.LENGTH_LONG).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        tvTime = findViewById(R.id.tvTime);
        tvDistance = findViewById(R.id.tvDistance);
        tvPace = findViewById(R.id.tvPace);
        btnStart = findViewById(R.id.btnStart);
        btnPauseResume = findViewById(R.id.btnPauseResume);
        btnFinish = findViewById(R.id.btnFinish);
        btnBack = findViewById(R.id.btnBack);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        btnBack.setOnClickListener(v -> finish());

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        setupTimer();
        setupClickListeners();
    }

    private void setupClickListeners() {
        btnStart.setOnClickListener(v -> startRun());

        btnPauseResume.setOnClickListener(v -> {
            if (isPaused) {
                resumeRun();
            } else {
                pauseRun();
            }
        });

        btnFinish.setOnClickListener(v -> finishRun());
    }

    private void startRun() {
        isTracking = true;
        isPaused = false;
        secondsElapsed = 0;
        totalDistanceMeters = 0.0;
        routePoints.clear();
        if (routePolyline != null) {
            routePolyline.remove();
        }

        btnStart.setVisibility(View.GONE);
        btnPauseResume.setVisibility(View.VISIBLE);
        btnFinish.setVisibility(View.VISIBLE);
        btnPauseResume.setText("Pause");

        startTimer();
        startLocationUpdates();
        Toast.makeText(this, "Cardio Run Started!", Toast.LENGTH_SHORT).show();
    }

    private void pauseRun() {
        isPaused = true;
        stopTimer();
        stopLocationUpdates();
        btnPauseResume.setText("Resume");
        Toast.makeText(this, "Run Paused", Toast.LENGTH_SHORT).show();
    }

    private void resumeRun() {
        isPaused = false;
        startTimer();
        startLocationUpdates();
        btnPauseResume.setText("Pause");
        Toast.makeText(this, "Run Resumed", Toast.LENGTH_SHORT).show();
    }

    private void finishRun() {
        isTracking = false;
        isPaused = false;
        stopTimer();
        stopLocationUpdates();

        // Calculate final stats
        double distanceKm = totalDistanceMeters / 1000.0;
        String timeStr = formatTime(secondsElapsed);
        String paceStr = calculatePace(secondsElapsed, distanceKm);

        // Show Summary Dialog
        new AlertDialog.Builder(this)
                .setTitle("🏃 Run Summary")
                .setMessage(String.format(Locale.US,
                        "Great job on your Cardio Run!\n\nDuration: %s\nDistance: %.2f km\nAverage Pace: %s /km",
                        timeStr, distanceKm, paceStr))
                .setPositiveButton("Save & Exit", (dialog, which) -> finish())
                .setNeutralButton("Discard", (dialog, which) -> {
                    // Reset or finish
                    finish();
                })
                .setCancelable(false)
                .show();
    }

    private void setupTimer() {
        timerRunnable = new Runnable() {
            @Override
            public void run() {
                if (isTracking && !isPaused) {
                    secondsElapsed++;
                    tvTime.setText(formatTime(secondsElapsed));

                    double distanceKm = totalDistanceMeters / 1000.0;
                    tvDistance.setText(String.format(Locale.US, "%.2f km", distanceKm));
                    tvPace.setText(calculatePace(secondsElapsed, distanceKm));
                }
                timerHandler.postDelayed(this, 1000);
            }
        };
    }

    private void startTimer() {
        timerHandler.postDelayed(timerRunnable, 1000);
    }

    private void stopTimer() {
        timerHandler.removeCallbacks(timerRunnable);
    }

    private String formatTime(long seconds) {
        long mins = seconds / 60;
        long secs = seconds % 60;
        return String.format(Locale.US, "%02d:%02d", mins, secs);
    }

    private String calculatePace(long seconds, double distanceKm) {
        if (distanceKm < 0.02) {
            return "0'00\"";
        }
        double totalMinutes = seconds / 60.0;
        double paceMinutesPerKm = totalMinutes / distanceKm;
        int mins = (int) paceMinutesPerKm;
        int secs = (int) ((paceMinutesPerKm - mins) * 60);
        return String.format(Locale.US, "%d'%02d\"", mins, secs);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Custom dark styling or UI settings
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setCompassEnabled(true);

        checkLocationPermissionsAndInit();
    }

    private void checkLocationPermissionsAndInit() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            enableUserLocationAndStart();
        } else {
            locationPermissionLauncher.launch(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            });
        }
    }

    private void enableUserLocationAndStart() {
        try {
            if (mMap != null) {
                mMap.setMyLocationEnabled(true);
            }

            fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
                if (location != null && mMap != null) {
                    LatLng currentLatLng = new LatLng(location.getLatitude(), location.getLongitude());
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 16f));
                }
            });
        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }

    private void startLocationUpdates() {
        locationRequest = new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 3000)
                .setMinUpdateIntervalMillis(1500)
                .build();

        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) {
                    return;
                }
                for (Location location : locationResult.getLocations()) {
                    if (location != null && isTracking && !isPaused) {
                        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());

                        if (lastLocation != null) {
                            double distance = lastLocation.distanceTo(location);
                            if (distance < 50 && distance > 0.5) { // filter out GPS jitter
                                totalDistanceMeters += distance;
                            }
                        }
                        lastLocation = location;

                        routePoints.add(latLng);
                        updateRoutePolyline();

                        mMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));
                    }
                }
            }
        };

        try {
            fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper());
        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }

    private void stopLocationUpdates() {
        if (fusedLocationClient != null && locationCallback != null) {
            fusedLocationClient.removeLocationUpdates(locationCallback);
        }
    }

    private void updateRoutePolyline() {
        if (mMap == null) return;
        if (routePolyline == null) {
            PolylineOptions options = new PolylineOptions()
                    .addAll(routePoints)
                    .width(12f)
                    .color(Color.parseColor("#5BA0F5")); // Blue accent matching Figma
            routePolyline = mMap.addPolyline(options);
        } else {
            routePolyline.setPoints(routePoints);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopTimer();
        stopLocationUpdates();
    }
}
