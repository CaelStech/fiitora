package com.example.fitorafitnessapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ExercisePreferencesActivity extends AppCompatActivity {

    TextView tvSelectedCount;
    Button btnStartJourney;

    ArrayList<String> selectedExercises = new ArrayList<>();

    LinearLayout[] cards;
    String[] exerciseNames = {
            "Cardio",
            "Strength",
            "HIIT",
            "Yoga",
            "Stretching",
            "Swimming",
            "Cycling",
            "Boxing",
            "Dance",
            "Sports",
            "Calisthenics",
            "Pilates",
            "Walking",
            "Jogging",
            "Core"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_preferences);

        tvSelectedCount = findViewById(R.id.tvSelectedCount);
        btnStartJourney = findViewById(R.id.btnStartJourney);

        cards = new LinearLayout[]{
                findViewById(R.id.cardCardio),
                findViewById(R.id.cardStrength),
                findViewById(R.id.cardHIIT),
                findViewById(R.id.cardYoga),
                findViewById(R.id.cardStretching),
                findViewById(R.id.cardSwimming),
                findViewById(R.id.cardCycling),
                findViewById(R.id.cardBoxing),
                findViewById(R.id.cardDance),
                findViewById(R.id.cardSports),
                findViewById(R.id.cardCalisthenics),
                findViewById(R.id.cardPilates),
                findViewById(R.id.cardWalking),
                findViewById(R.id.cardJogging),
                findViewById(R.id.cardCore)
        };

        for (int i = 0; i < cards.length; i++) {

            final int position = i;

            cards[i].setOnClickListener(v -> {

                String exercise = exerciseNames[position];

                if (selectedExercises.contains(exercise)) {

                    selectedExercises.remove(exercise);
                    cards[position].setSelected(false);

                } else {

                    selectedExercises.add(exercise);
                    cards[position].setSelected(true);
                }

                tvSelectedCount.setText(
                        "Choose your preferred workout types ("
                                + selectedExercises.size()
                                + " selected)"
                );
            });
        }

        btnStartJourney.setOnClickListener(v -> {

            getSharedPreferences(
                    "FITORA_ACCOUNTS",
                    MODE_PRIVATE
            ).edit()
                    .putString(
                            "exercise_preferences",
                            selectedExercises.toString()
                    )
                    .apply();

            Intent intent = new Intent(
                    ExercisePreferencesActivity.this,
                    HomeActivity.class
            );

            startActivity(intent);
            finish();
        });
    }
}