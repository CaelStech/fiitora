plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.fitorafitnessapp"
    compileSdk {
        version = release(37)
    }

    defaultConfig {
        applicationId = "com.example.fitorafitnessapp"
        minSdk = 27
        targetSdk = 37
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            optimization {
                enable = false
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
} 

dependencies {
    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity.ktx)
    implementation(libs.constraintlayout)

    // Jetpack Compose
    implementation(platform("androidx.compose:compose-bom:2026.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    // Icons
    implementation("androidx.compose.material:material-icons-extended")
    // Google Maps & Location
    implementation("com.google.android.gms:play-services-maps:19.0.0")
    implementation("com.google.android.gms:play-services-location:21.3.0")
    // Health Connect
    implementation("androidx.health.connect:connect-client:1.1.0")

    // Google authorization
    implementation("com.google.android.gms:play-services-auth:21.4.0")
    // HTTP request
    implementation("com.squareup.okhttp3:okhttp:5.1.0")
    // JSON
    implementation("org.json:json:20250517")
    debugImplementation("androidx.compose.ui:ui-tooling")
}